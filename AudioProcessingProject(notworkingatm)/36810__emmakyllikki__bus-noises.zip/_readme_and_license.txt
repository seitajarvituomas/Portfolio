Sound pack downloaded from Freesound
----------------------------------------

"bus noises"

This pack of sounds contains sounds by the following user:
 - emmakyllikki ( https://freesound.org/people/emmakyllikki/ )

You can find this pack online at: https://freesound.org/people/emmakyllikki/packs/36810/


Licenses in this pack (see below for individual sound licenses)
---------------------------------------------------------------

Creative Commons 0: http://creativecommons.org/publicdomain/zero/1.0/


Sounds in this pack
-------------------

  * 658721__emmakyllikki__bus3.wav
    * url: https://freesound.org/s/658721/
    * license: Creative Commons 0
  * 658720__emmakyllikki__bus9.wav
    * url: https://freesound.org/s/658720/
    * license: Creative Commons 0
  * 658719__emmakyllikki__bus5.wav
    * url: https://freesound.org/s/658719/
    * license: Creative Commons 0
  * 658718__emmakyllikki__bus4.wav
    * url: https://freesound.org/s/658718/
    * license: Creative Commons 0
  * 658717__emmakyllikki__bus7.wav
    * url: https://freesound.org/s/658717/
    * license: Creative Commons 0
  * 658716__emmakyllikki__bus20.wav
    * url: https://freesound.org/s/658716/
    * license: Creative Commons 0
  * 658715__emmakyllikki__bus6.wav
    * url: https://freesound.org/s/658715/
    * license: Creative Commons 0
  * 658714__emmakyllikki__bus19.wav
    * url: https://freesound.org/s/658714/
    * license: Creative Commons 0
  * 658713__emmakyllikki__bus8.wav
    * url: https://freesound.org/s/658713/
    * license: Creative Commons 0
  * 658712__emmakyllikki__bus2.wav
    * url: https://freesound.org/s/658712/
    * license: Creative Commons 0
  * 658710__emmakyllikki__bus17.wav
    * url: https://freesound.org/s/658710/
    * license: Creative Commons 0
  * 658709__emmakyllikki__bus18.wav
    * url: https://freesound.org/s/658709/
    * license: Creative Commons 0
  * 658708__emmakyllikki__bus13.wav
    * url: https://freesound.org/s/658708/
    * license: Creative Commons 0
  * 658707__emmakyllikki__bus14.wav
    * url: https://freesound.org/s/658707/
    * license: Creative Commons 0
  * 658706__emmakyllikki__bus15.wav
    * url: https://freesound.org/s/658706/
    * license: Creative Commons 0
  * 658705__emmakyllikki__bus16.wav
    * url: https://freesound.org/s/658705/
    * license: Creative Commons 0
  * 658704__emmakyllikki__bus1.wav
    * url: https://freesound.org/s/658704/
    * license: Creative Commons 0
  * 658703__emmakyllikki__bus10.wav
    * url: https://freesound.org/s/658703/
    * license: Creative Commons 0
  * 658702__emmakyllikki__bus11.wav
    * url: https://freesound.org/s/658702/
    * license: Creative Commons 0
  * 658701__emmakyllikki__bus12.wav
    * url: https://freesound.org/s/658701/
    * license: Creative Commons 0


