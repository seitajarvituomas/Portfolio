Sound pack downloaded from Freesound
----------------------------------------

"Car sounds"

This pack of sounds contains sounds by the following user:
 - aaroan ( https://freesound.org/people/aaroan/ )

You can find this pack online at: https://freesound.org/people/aaroan/packs/39950/


Licenses in this pack (see below for individual sound licenses)
---------------------------------------------------------------

Creative Commons 0: http://creativecommons.org/publicdomain/zero/1.0/


Sounds in this pack
-------------------

  * 714999__aaroan__auto9.wav
    * url: https://freesound.org/s/714999/
    * license: Creative Commons 0
  * 714998__aaroan__auto8.wav
    * url: https://freesound.org/s/714998/
    * license: Creative Commons 0
  * 714997__aaroan__auto7.wav
    * url: https://freesound.org/s/714997/
    * license: Creative Commons 0
  * 714996__aaroan__auto6.wav
    * url: https://freesound.org/s/714996/
    * license: Creative Commons 0
  * 714995__aaroan__auto5.wav
    * url: https://freesound.org/s/714995/
    * license: Creative Commons 0
  * 714994__aaroan__auto4.wav
    * url: https://freesound.org/s/714994/
    * license: Creative Commons 0
  * 714993__aaroan__auto3.wav
    * url: https://freesound.org/s/714993/
    * license: Creative Commons 0
  * 714992__aaroan__auto2.wav
    * url: https://freesound.org/s/714992/
    * license: Creative Commons 0
  * 714991__aaroan__auto14.wav
    * url: https://freesound.org/s/714991/
    * license: Creative Commons 0
  * 714990__aaroan__auto13.wav
    * url: https://freesound.org/s/714990/
    * license: Creative Commons 0
  * 714989__aaroan__auto12.wav
    * url: https://freesound.org/s/714989/
    * license: Creative Commons 0
  * 714988__aaroan__auto11.wav
    * url: https://freesound.org/s/714988/
    * license: Creative Commons 0
  * 714987__aaroan__auto10.wav
    * url: https://freesound.org/s/714987/
    * license: Creative Commons 0
  * 714986__aaroan__auto1.wav
    * url: https://freesound.org/s/714986/
    * license: Creative Commons 0


